﻿using stochastic_engine.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace stochastic_engine.Engine
{
    public class Scheduler
    {
        public int Time { get; set; }

        public Dictionary<int, Event> FutureEventsList = new Dictionary<int, Event>();

        public List<Event> Events = new List<Event>();
        public List<Resource> Resources = new List<Resource>();
        public List<EntitySet> EntitiesSets = new List<EntitySet>();
        public List<Entity> Entities = new List<Entity>();

        public void ScheduleNow(Event e)
        {
            FutureEventsList.Add(Time, e);
        }

        public void ScheduleAt(Event e, int timeToEvent)
        {
            FutureEventsList.Add(Time + timeToEvent, e);
        }

        public void ScheduleIn(Event e, int time)
        {
            FutureEventsList.Add(time, e);
        }

        public void WaitFor(int time)
        {
            Time += time;
        }

        public List<Event> GetEvents()
        {
            return FutureEventsList.Values.Where(e => !e.AlreadyExecuted).ToList();
        }

        public Event GetNextEvent()
        {
            foreach (int k in FutureEventsList.Keys)
            {
                if (k >= Time)
                    return FutureEventsList.ElementAt(k).Value;
            }
            return null;
        }

        public void Simulate()
        {
            while (GetNextEvent() != null)
            {
                Event nextEvent = GetNextEvent();
                Console.WriteLine("Running event: " + nextEvent.Name);
            }
        }

        public void ExecuteEvent(Event e)
        {
            Time = FutureEventsList.FirstOrDefault(fe => fe.Equals(e)).Key;
            e.Execute();
        }

        public Entity CreateEntity(Entity entity)
        {
            entity.CreationTime = Time;
            entity.Scheduler = this;
            entity.Id = Guid.NewGuid();
            Entities.Add(entity);

            Console.WriteLine("Created Entity: " + entity.Id + "-" + entity.Name);

            return entity;
        }

        public Entity GetEntity(Guid id)
        {
            return Entities.Where(e => e.Id == id)?.FirstOrDefault();
        }

        public Resource CreateResource(string name, int quantity)
        {
            Resource resource = new Resource(name, quantity, this);
            resource.Id = Guid.NewGuid();
            Resources.Add(resource);

            Console.WriteLine("Created resource: " + resource.Id + " - " + resource.Name);

            return resource;
        }

        public Resource GetResource(Guid id)
        {
            return Resources.Where(r => r.Id == id)?.FirstOrDefault();
        }

        public Event CreateEvent(Event e)
        {
            e.EventId = (Guid.NewGuid());
            Events.Add(e);
            return e;
        }

        public Event GetEvent(Guid id)
        {
            return Events.Where(e => e.EventId == id)?.FirstOrDefault();
        }
    }
}
